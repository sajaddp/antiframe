<?php
/**
 * Plugin Name:	Antifream
 * Plugin URI:	http://Pelakweb.ir
 * Description:	جلوگیری از نمایش نوشته های سایت به صورت آی فریم و نمایش پیام به کاربر مشاهده کننده.
 * Version:	1.0
 * Author:	Sajad Dehshiri
 * Author URI:	http://Pelakweb.ir
 **/

if(!function_exists('Antiframe')) {
	function Antiframe() {
		$site_title = get_bloginfo( 'name' );
		$site_url = network_site_url( '/' );
		$site_lang = get_bloginfo( 'language');
		if ($site_lang == 'fa-IR'){
			$code = '<!-- Antifream by Pelakweb.ir -->' . "\n";
			$code .= "<script type=\"text/javascript\">function breakout(){if (top === window) {} else {alert('این نوشته به صورت غیر قانونی از وبگاه $site_title فراخوانی شده است.\\nجهت حمایت از ما لطفا نوشته را از آدرس حقیقی مطالعه بفرمایید.:\\n'+window.location.href);window.location = '$site_url'}}breakout();</script>";
			$code .= '<!-- /Antifream -->';
		}else{
			$code = '<!-- Antifream by Pelakweb.ir -->' . "\n";
			$code .= "<script type=\"text/javascript\">function breakout(){if (top === window) {} else {alert('Please read the article at $site_title:\\n'+window.location.href);window.location = '$site_url'}}breakout();</script>";
			$code .= '<!-- /Antifream -->';
		}
		$code = apply_filters('Antiframe', $code);
		echo $code;
		return;
	}
}

add_action('wp_head', 'Antiframe');
?>