=== Plugin Name ===
Contributors: SajadDP
Donate link: http://pelakweb.ir/
Tags: iframe
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

By this plugin you can forbid load your site in iframe and alert the visitors to open your site.

== Installation ==

1. Upload `Antifream` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. You can find screenshot in plugin directory

== Frequently Asked Questions ==

You can sumbit it in http://ume.ir/

== Changelog ==

= 1.0 =
* First release.

== Upgrade Notice ==

= 1.0 =
* First release.
